"""
CropGuard AI Backend — FastAPI
Handles sync from mobile, treatment recommendations, and analytics
"""
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
import uvicorn

app = FastAPI(title="CropGuard API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)


class ScanCreateSchema(BaseModel):
    farm_id:       int
    disease_class: str
    confidence:    float
    crop_type:     str
    latitude:      Optional[float] = None
    longitude:     Optional[float] = None
    image_s3_key:  Optional[str]   = None


class TreatmentEngine:
    DB = {
        "Tomato_Early_blight": {
            "disease_name": "Early Blight (Alternaria solani)",
            "severity":     "moderate",
            "urgency":      "treat within 3-5 days",
            "organic":      ["Neem oil spray (5ml/L) every 7 days",
                             "Remove infected lower leaves immediately",
                             "Copper-based Bordeaux mixture (1%)"],
            "chemical":     ["Mancozeb 75% WP @ 2g/L water",
                             "Chlorothalonil 75% WP @ 2g/L",
                             "Iprodione 50% WP @ 1g/L (severe cases)"],
            "prevention":   ["Avoid overhead irrigation — use drip",
                             "Crop rotation: no tomato/potato consecutively",
                             "Use resistant varieties (Pusa Ruby, Arka Vikas)"]
        },
        "Tomato_Late_blight": {
            "disease_name": "Late Blight (Phytophthora infestans)",
            "severity":     "high",
            "urgency":      "treat within 24 hours — spreads rapidly",
            "organic":      ["Copper hydroxide spray immediately",
                             "Destroy ALL infected material",
                             "Trichoderma viride biocontrol"],
            "chemical":     ["Metalaxyl + Mancozeb (Ridomil Gold) @ 2.5g/L",
                             "Cymoxanil 8% + Mancozeb 64% @ 3g/L"],
            "prevention":   ["Plant certified disease-free seed",
                             "Maintain 60cm spacing for airflow",
                             "Monitor during cool wet weather (10-25°C, >90% RH)"]
        },
    }

    def get_treatment(self, disease_class: str) -> Optional[dict]:
        entry = self.DB.get(disease_class)
        if not entry:
            key = "_".join(disease_class.split("_")[1:])
            for k, v in self.DB.items():
                if key.lower() in k.lower():
                    return v
        return entry


treatment_engine = TreatmentEngine()

# In-memory store for demo (replace with real DB in production)
scan_store = []
scan_id_counter = 1


@app.post("/api/v1/scans", tags=["Scans"])
async def create_scan(scan: ScanCreateSchema):
    """Sync scan result from mobile device"""
    global scan_id_counter
    record = {
        "id":            scan_id_counter,
        "farm_id":       scan.farm_id,
        "disease_class": scan.disease_class,
        "confidence":    scan.confidence,
        "crop_type":     scan.crop_type,
        "latitude":      scan.latitude,
        "longitude":     scan.longitude,
    }
    scan_store.append(record)
    scan_id_counter += 1
    treatment = treatment_engine.get_treatment(scan.disease_class)
    return {"scan": record, "treatment": treatment}


@app.get("/api/v1/farms/{farm_id}/history", tags=["Farms"])
async def get_farm_disease_history(farm_id: int):
    scans = [s for s in scan_store if s["farm_id"] == farm_id]
    disease_counts: dict = {}
    for s in scans:
        disease_counts[s["disease_class"]] = disease_counts.get(s["disease_class"], 0) + 1
    return {
        "farm_id":       farm_id,
        "total_scans":   len(scans),
        "disease_trend": disease_counts,
        "scans":         scans[:20]
    }


@app.get("/api/v1/treatments/{disease_class}", tags=["Treatments"])
async def get_treatment(disease_class: str):
    t = treatment_engine.get_treatment(disease_class)
    if not t:
        raise HTTPException(status_code=404, detail="Disease not found")
    return t


@app.get("/api/v1/analytics/heatmap", tags=["Analytics"])
async def disease_heatmap():
    return [
        {"disease": s["disease_class"], "lat": s["latitude"],
         "lon": s["longitude"], "crop": s["crop_type"]}
        for s in scan_store if s.get("latitude")
    ]


@app.get("/api/v1/health")
async def health():
    return {"status": "ok", "scans_in_memory": len(scan_store)}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
