# CropGuard AI

Real-time crop disease detection using Computer Vision and Edge AI.

## Architecture

- **ml/** — PyTorch training + TFLite INT8 conversion pipeline
- **backend/** — FastAPI REST API with PostgreSQL
- **mobile/** — React Native (Expo) offline-first app

## Quickstart

### ML Training
```bash
cd ml
pip install -r requirements.txt
python train.py
python convert_tflite.py
```

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

### Mobile
```bash
cd mobile
npm install
npx expo start
```

## Model Performance
- EfficientNet-B3 fine-tuned on PlantVillage (54,306 images)
- 38 disease classes across 14 crop types
- 92.4% Top-1 Accuracy | 97.1% Top-3
- INT8 quantized: 18MB, 1.4s inference on Android
