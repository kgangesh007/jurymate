"""
CropGuard AI - Model Training Pipeline
EfficientNet-B3 fine-tuned on PlantVillage + custom field images
"""
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from torchvision import transforms, datasets, models
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
import os, json

DATASET_PATH = "./data/plantvillage"
MODEL_OUT    = "./models/cropguard_efficientnet_b3.pt"
CLASSES_OUT  = "./models/class_names.json"
NUM_CLASSES  = 38
BATCH_SIZE   = 32
EPOCHS       = 50
LR           = 1e-4
DEVICE       = torch.device("cuda" if torch.cuda.is_available() else "cpu")

train_tf = transforms.Compose([
    transforms.RandomResizedCrop(300),
    transforms.RandomHorizontalFlip(),
    transforms.RandomVerticalFlip(),
    transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2),
    transforms.RandomRotation(30),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

val_tf = transforms.Compose([
    transforms.Resize(320),
    transforms.CenterCrop(300),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])


class FocalLoss(nn.Module):
    def __init__(self, gamma=2.0):
        super().__init__()
        self.gamma = gamma
        self.ce = nn.CrossEntropyLoss(reduction="none")

    def forward(self, logits, targets):
        ce = self.ce(logits, targets)
        pt = torch.exp(-ce)
        return ((1 - pt) ** self.gamma * ce).mean()


def build_model(num_classes: int) -> nn.Module:
    model = models.efficientnet_b3(weights=models.EfficientNet_B3_Weights.DEFAULT)
    in_features = model.classifier[1].in_features
    model.classifier = nn.Sequential(
        nn.Dropout(p=0.4),
        nn.Linear(in_features, num_classes)
    )
    return model


def cutmix_batch(images, labels, alpha=1.0):
    lam = torch.distributions.Beta(alpha, alpha).sample().item()
    rand_idx = torch.randperm(images.size(0)).to(DEVICE)
    shuffled_labels = labels[rand_idx]
    cx = torch.randint(images.size(3), (1,)).item()
    cy = torch.randint(images.size(2), (1,)).item()
    cut_w = int(images.size(3) * (1 - lam) ** 0.5)
    cut_h = int(images.size(2) * (1 - lam) ** 0.5)
    x1, x2 = max(0, cx - cut_w // 2), min(images.size(3), cx + cut_w // 2)
    y1, y2 = max(0, cy - cut_h // 2), min(images.size(2), cy + cut_h // 2)
    images[:, :, y1:y2, x1:x2] = images[rand_idx, :, y1:y2, x1:x2]
    lam = 1 - (x2 - x1) * (y2 - y1) / (images.size(2) * images.size(3))
    return images, labels, shuffled_labels, lam


def train():
    dataset = datasets.ImageFolder(DATASET_PATH, transform=train_tf)
    n_val = int(len(dataset) * 0.15)
    n_train = len(dataset) - n_val
    train_ds, val_ds = random_split(dataset, [n_train, n_val])
    val_ds.dataset.transform = val_tf

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=4)
    val_loader   = DataLoader(val_ds,   batch_size=BATCH_SIZE, shuffle=False, num_workers=4)

    model = build_model(NUM_CLASSES).to(DEVICE)
    criterion = FocalLoss(gamma=2.0)
    optimizer = AdamW(model.parameters(), lr=LR, weight_decay=1e-5)
    scheduler = CosineAnnealingLR(optimizer, T_max=EPOCHS)

    best_acc = 0.0
    for epoch in range(1, EPOCHS + 1):
        model.train()
        running_loss = 0.0
        for images, labels in train_loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            if torch.rand(1).item() > 0.5:
                images, lbl_a, lbl_b, lam = cutmix_batch(images, labels)
                out  = model(images)
                loss = lam * criterion(out, lbl_a) + (1 - lam) * criterion(out, lbl_b)
            else:
                out  = model(images)
                loss = criterion(out, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        scheduler.step()

        model.eval()
        correct = total = 0
        with torch.no_grad():
            for images, labels in val_loader:
                images, labels = images.to(DEVICE), labels.to(DEVICE)
                preds = model(images).argmax(dim=1)
                correct += (preds == labels).sum().item()
                total   += labels.size(0)
        acc = correct / total
        print(f"Epoch {epoch:02d}/{EPOCHS}  Loss: {running_loss/len(train_loader):.4f}  Val Acc: {acc:.4f}")
        if acc > best_acc:
            best_acc = acc
            torch.save(model.state_dict(), MODEL_OUT)

    os.makedirs(os.path.dirname(CLASSES_OUT), exist_ok=True)
    with open(CLASSES_OUT, "w") as f:
        json.dump(dataset.classes, f, indent=2)
    print(f"\nBest Val Accuracy: {best_acc:.4f}")

if __name__ == "__main__":
    train()
