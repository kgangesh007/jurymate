"""
Rule-based treatment recommendation engine.
For each disease, returns organic + chemical treatments, severity, urgency.
"""
from typing import Optional


TREATMENTS = {
    "Tomato_Early_blight": {
        "disease_name": "Early Blight (Alternaria solani)",
        "severity":     "moderate",
        "urgency":      "treat within 3-5 days",
        "organic":  ["Neem oil spray (5ml/L) every 7 days",
                     "Remove infected lower leaves immediately",
                     "Copper-based Bordeaux mixture (1% solution)"],
        "chemical": ["Mancozeb 75% WP @ 2g/L water",
                     "Chlorothalonil 75% WP @ 2g/L water",
                     "Iprodione 50% WP @ 1g/L (for severe cases)"],
        "prevention": ["Use drip irrigation, avoid overhead watering",
                       "Rotate crops — don't plant tomato/potato consecutively",
                       "Use disease-resistant varieties (Pusa Ruby, Arka Vikas)"],
        "local_language_key": "tomato_early_blight"
    },
    "Tomato_Late_blight": {
        "disease_name": "Late Blight (Phytophthora infestans)",
        "severity":     "high",
        "urgency":      "treat within 24 hours — spreads rapidly",
        "organic":  ["Copper hydroxide spray immediately",
                     "Remove and destroy ALL infected plant material",
                     "Trichoderma viride biocontrol agent"],
        "chemical": ["Metalaxyl + Mancozeb (Ridomil Gold) @ 2.5g/L",
                     "Cymoxanil 8% + Mancozeb 64% WP @ 3g/L",
                     "Dimethomorph 50% WP @ 1g/L (alternation)"],
        "prevention": ["Plant certified disease-free seed",
                       "Maintain 60cm spacing for air circulation",
                       "Monitor during cool wet weather (10-25°C, >90% RH)"],
        "local_language_key": "tomato_late_blight"
    },
    "Potato_Late_blight": {
        "disease_name": "Late Blight (Phytophthora infestans)",
        "severity":     "critical",
        "urgency":      "immediate action required",
        "organic":  ["Copper-based sprays every 5 days",
                     "Destroy infected tubers immediately"],
        "chemical": ["Metalaxyl @ 2.5g/L", "Propamocarb 72.2% SL @ 3ml/L"],
        "prevention": ["Use certified seed potatoes only",
                       "Hill up plants properly to protect tubers"],
        "local_language_key": "potato_late_blight"
    },
    "Corn_(maize)_Common_rust": {
        "disease_name": "Common Rust (Puccinia sorghi)",
        "severity":     "moderate",
        "urgency":      "treat within 5-7 days",
        "organic":  ["Sulfur-based fungicide spray",
                     "Remove heavily infected leaves"],
        "chemical": ["Propiconazole 25% EC @ 1ml/L",
                     "Tebuconazole 25.9% EC @ 1ml/L"],
        "prevention": ["Plant rust-resistant hybrids",
                       "Avoid late planting when humidity is high"],
        "local_language_key": "corn_common_rust"
    },
}


class TreatmentEngine:
    def __init__(self):
        self.db = TREATMENTS
        print(f"TreatmentEngine loaded: {len(self.db)} diseases")

    def get_treatment(self, disease_class: str, crop_type: str = None) -> Optional[dict]:
        entry = self.db.get(disease_class)
        if not entry:
            # Fuzzy match by disease suffix
            key = "_".join(disease_class.split("_")[1:]) if "_" in disease_class else disease_class
            for k, v in self.db.items():
                if key.lower() in k.lower():
                    entry = v
                    break
        return entry

    def get_all_diseases(self) -> list:
        return list(self.db.keys())
