/**
 * CropGuard MLService
 * TFLite inference + offline result caching via SQLite
 */
import * as tf from '@tensorflow/tfjs';
import { loadTensorflowModel, bundleResourceIO } from '@tensorflow/tfjs-react-native';
import SQLite from 'react-native-sqlite-storage';
import modelJson from '../../assets/model/model.json';
import modelWeights from '../../assets/model/group1-shard1of1.bin';
import classNames from '../../assets/model/class_names.json';

const CONFIDENCE_THRESHOLD = 0.70;
const DB_NAME = 'cropguard_local.db';

interface PredictionResult {
  status: 'success' | 'low_confidence' | 'error';
  disease?: string;
  confidence?: number;
  isHealthy?: boolean;
  top3?: { class: string; confidence: number }[];
  treatmentKey?: string;
  message?: string;
}

interface CachedScan {
  disease: string;
  confidence: number;
  isHealthy: boolean;
  imageUri: string;
  cropHint: string | null;
  synced: number;
}

class MLService {
  private model: tf.GraphModel | null = null;
  private db: SQLite.SQLiteDatabase | null = null;

  async initialize(): Promise<void> {
    await tf.ready();
    this.model = await loadTensorflowModel(bundleResourceIO(modelJson, modelWeights));
    this.db = await SQLite.openDatabase({ name: DB_NAME, location: 'default' });
    await this.initSchema();
    console.log('[MLService] Ready ✅');
  }

  async predict(imageUri: string, cropHint?: string): Promise<PredictionResult> {
    if (!this.model) throw new Error('Model not initialized — call initialize() first');

    try {
      const tensor = await this.imageToTensor(imageUri);
      const logits = this.model.predict(tensor) as tf.Tensor;
      const probs  = await tf.softmax(logits).array() as number[][];
      const flat   = probs[0];

      const top3Idx  = [...flat.keys()].sort((a, b) => flat[b] - flat[a]).slice(0, 3);
      const top1Conf = flat[top3Idx[0]];
      const top1Cls  = (classNames as string[])[top3Idx[0]];

      tf.dispose([tensor, logits]);

      if (top1Conf < CONFIDENCE_THRESHOLD) {
        return {
          status: 'low_confidence',
          confidence: top1Conf,
          message: 'Take another photo from a different angle for a better result.',
        };
      }

      const isHealthy = top1Cls.toLowerCase().includes('healthy');
      const [, ...rest] = top1Cls.split('_');
      const disease = rest.join(' ');

      const result: PredictionResult = {
        status: 'success',
        disease,
        confidence: top1Conf,
        isHealthy,
        treatmentKey: top1Cls,
        top3: top3Idx.map(i => ({
          class: (classNames as string[])[i],
          confidence: flat[i],
        })),
      };

      await this.cacheScan({
        disease: top1Cls,
        confidence: top1Conf,
        isHealthy,
        imageUri,
        cropHint: cropHint ?? null,
        synced: 0,
      });

      return result;
    } catch (err) {
      console.error('[MLService] Predict error:', err);
      return { status: 'error', message: String(err) };
    }
  }

  async getUnsynced(): Promise<any[]> {
    return new Promise((resolve, reject) => {
      this.db!.transaction(tx => {
        tx.executeSql(
          'SELECT * FROM scans WHERE synced = 0 ORDER BY created_at DESC LIMIT 50',
          [],
          (_, { rows }) => resolve(rows.raw()),
          (_, err) => { reject(err); return true; }
        );
      });
    });
  }

  async markSynced(ids: number[]): Promise<void> {
    const placeholders = ids.map(() => '?').join(',');
    return new Promise((resolve, reject) => {
      this.db!.transaction(tx => {
        tx.executeSql(
          `UPDATE scans SET synced = 1 WHERE id IN (${placeholders})`,
          ids,
          () => resolve(),
          (_, err) => { reject(err); return true; }
        );
      });
    });
  }

  private async imageToTensor(uri: string): Promise<tf.Tensor4D> {
    const { decodeJpeg } = await import('@tensorflow/tfjs-react-native');
    const response = await fetch(uri);
    const buffer   = await response.arrayBuffer();
    const raw      = new Uint8Array(buffer);
    const imageTensor = decodeJpeg(raw);
    const resized     = tf.image.resizeBilinear(imageTensor as tf.Tensor3D, [300, 300]);
    const normalized  = resized.div(255.0);
    const meaned      = normalized.sub([0.485, 0.456, 0.406]);
    const stdded      = meaned.div([0.229, 0.224, 0.225]);
    tf.dispose([imageTensor, resized, normalized, meaned]);
    return stdded.expandDims(0) as tf.Tensor4D;
  }

  private async cacheScan(data: CachedScan): Promise<void> {
    return new Promise((resolve, reject) => {
      this.db!.transaction(tx => {
        tx.executeSql(
          `INSERT INTO scans (disease, confidence, is_healthy, image_uri, crop_hint, synced)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [data.disease, data.confidence, data.isHealthy ? 1 : 0,
           data.imageUri, data.cropHint, data.synced],
          () => resolve(),
          (_, err) => { reject(err); return true; }
        );
      });
    });
  }

  private async initSchema(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.db!.transaction(tx => {
        tx.executeSql(`
          CREATE TABLE IF NOT EXISTS scans (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            disease     TEXT    NOT NULL,
            confidence  REAL    NOT NULL,
            is_healthy  INTEGER DEFAULT 0,
            image_uri   TEXT,
            crop_hint   TEXT,
            synced      INTEGER DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `, [], () => resolve(), (_, err) => { reject(err); return true; });
      });
    });
  }
}

export const mlService = new MLService();
