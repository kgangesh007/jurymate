/**
 * ScanScreen — Main camera + inference screen
 * Point → Capture → Diagnose in < 2 seconds
 */
import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ActivityIndicator, Alert
} from 'react-native';
import { Camera, CameraType } from 'expo-camera';
import * as ImageManipulator from 'expo-image-manipulator';
import { useNavigation } from '@react-navigation/native';
import { useNetInfo } from '@react-native-community/netinfo';
import { mlService } from '../services/MLService';

const CROP_TYPES = ['tomato', 'potato', 'corn', 'wheat'];

export default function ScanScreen() {
  const cameraRef = useRef<Camera>(null);
  const navigation = useNavigation<any>();
  const netInfo    = useNetInfo();

  const [isScanning, setIsScanning] = useState(false);
  const [cropHint,   setCropHint]   = useState<string>('tomato');
  const [permission, requestPermission] = Camera.useCameraPermissions();

  const handleCapture = useCallback(async () => {
    if (!cameraRef.current || isScanning) return;
    setIsScanning(true);

    try {
      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.85,
        skipProcessing: false,
      });

      // Resize to 300×300 for TFLite input
      const resized = await ImageManipulator.manipulateAsync(
        photo.uri,
        [{ resize: { width: 300, height: 300 } }],
        { compress: 0.9, format: ImageManipulator.SaveFormat.JPEG }
      );

      const result = await mlService.predict(resized.uri, cropHint);

      if (result.status === 'low_confidence') {
        Alert.alert('📷 Retake Needed', result.message ?? 'Confidence too low — try again');
        return;
      }

      if (result.status === 'success') {
        navigation.navigate('ResultScreen', { result, imageUri: resized.uri });
      }

      if (result.status === 'error') {
        Alert.alert('Error', result.message ?? 'Scan failed');
      }
    } catch (err) {
      Alert.alert('Error', 'Scan failed. Please try again.');
      console.error('[ScanScreen]', err);
    } finally {
      setIsScanning(false);
    }
  }, [isScanning, cropHint, navigation]);

  if (!permission) return <View />;

  if (!permission.granted) {
    return (
      <View style={styles.centered}>
        <Text style={styles.permText}>Camera access is needed for disease detection</Text>
        <TouchableOpacity style={styles.btn} onPress={requestPermission}>
          <Text style={styles.btnText}>Grant Permission</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Camera ref={cameraRef} style={styles.camera} type={CameraType.back}>

        {/* Crop selector */}
        <View style={styles.cropRow}>
          {CROP_TYPES.map(crop => (
            <TouchableOpacity
              key={crop}
              style={[styles.cropPill, cropHint === crop && styles.cropPillActive]}
              onPress={() => setCropHint(crop)}
            >
              <Text style={styles.cropPillText}>{crop}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Viewfinder guide */}
        <View style={styles.viewfinderContainer}>
          <View style={styles.viewfinder} />
          <Text style={styles.guide}>Center the leaf or stem in frame</Text>
        </View>

        {/* Shutter button */}
        <TouchableOpacity
          style={styles.shutter}
          onPress={handleCapture}
          disabled={isScanning}
        >
          {isScanning
            ? <ActivityIndicator size="large" color="#FFFFFF" />
            : <View style={styles.shutterInner} />
          }
        </TouchableOpacity>

        {/* Offline badge */}
        {!netInfo.isConnected && (
          <View style={styles.offlineBadge}>
            <Text style={styles.offlineText}>📶 Offline — results saved locally</Text>
          </View>
        )}
      </Camera>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  camera:    { flex: 1, justifyContent: 'space-between' },
  centered:  { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  permText:  { fontSize: 16, textAlign: 'center', marginBottom: 16, color: '#333' },
  btn: {
    backgroundColor: '#16A34A',
    paddingHorizontal: 24, paddingVertical: 12, borderRadius: 8,
  },
  btnText: { color: '#FFF', fontWeight: '700', fontSize: 16 },
  cropRow: { flexDirection: 'row', padding: 16, gap: 8, flexWrap: 'wrap' },
  cropPill: {
    backgroundColor: 'rgba(0,0,0,0.45)',
    paddingHorizontal: 14, paddingVertical: 6,
    borderRadius: 20,
  },
  cropPillActive: { backgroundColor: '#16A34A' },
  cropPillText:   { color: '#FFF', textTransform: 'capitalize', fontWeight: '600', fontSize: 14 },
  viewfinderContainer: { alignItems: 'center' },
  viewfinder: {
    width: 260, height: 260,
    borderWidth: 2, borderColor: '#4ADE80', borderRadius: 16,
  },
  guide: { color: '#FFF', marginTop: 8, fontSize: 13, textShadowColor: '#000', textShadowRadius: 4 },
  shutter: {
    alignSelf: 'center', marginBottom: 40,
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: '#16A34A',
    justifyContent: 'center', alignItems: 'center',
    shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 8, elevation: 8,
  },
  shutterInner: { width: 56, height: 56, borderRadius: 28, backgroundColor: '#FFF' },
  offlineBadge: {
    position: 'absolute', bottom: 130, alignSelf: 'center',
    backgroundColor: 'rgba(0,0,0,0.65)',
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20,
  },
  offlineText: { color: '#FCD34D', fontSize: 13, fontWeight: '500' },
});
