"""
Convert PyTorch EfficientNet-B3 -> TFLite INT8 quantized.
Output: models/cropguard.tflite (~18MB from 48MB float32)
"""
import torch
import torch.nn as nn
from torchvision import models
import tensorflow as tf
import numpy as np
import os, json

PT_MODEL_PATH = "./models/cropguard_efficientnet_b3.pt"
TFLITE_OUT    = "./models/cropguard.tflite"
NUM_CLASSES   = 38
REPRESENTATIVE_SAMPLES = 200


def load_pytorch_model(path: str) -> nn.Module:
    model = models.efficientnet_b3(weights=None)
    in_features = model.classifier[1].in_features
    model.classifier = nn.Sequential(
        nn.Dropout(p=0.4),
        nn.Linear(in_features, NUM_CLASSES)
    )
    model.load_state_dict(torch.load(path, map_location="cpu"))
    model.eval()
    return model


def pytorch_to_onnx(model: nn.Module, onnx_path: str):
    dummy = torch.randn(1, 3, 300, 300)
    torch.onnx.export(
        model, dummy, onnx_path,
        input_names=["image"],
        output_names=["logits"],
        dynamic_axes={"image": {0: "batch"}},
        opset_version=13
    )
    print(f"ONNX saved: {onnx_path}")


def representative_dataset_gen():
    """Calibration data for INT8 quantization"""
    np.random.seed(42)
    for _ in range(REPRESENTATIVE_SAMPLES):
        sample = np.random.randn(1, 300, 300, 3).astype(np.float32)
        sample = (sample - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]
        yield [sample]


def convert_to_tflite():
    model = load_pytorch_model(PT_MODEL_PATH)
    onnx_path = PT_MODEL_PATH.replace(".pt", ".onnx")
    pytorch_to_onnx(model, onnx_path)

    import onnx
    from onnx_tf.backend import prepare
    onnx_model = onnx.load(onnx_path)
    tf_rep = prepare(onnx_model)
    tf_saved = PT_MODEL_PATH.replace(".pt", "_tf_savedmodel")
    tf_rep.export_graph(tf_saved)

    converter = tf.lite.TFLiteConverter.from_saved_model(tf_saved)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = representative_dataset_gen
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type  = tf.int8
    converter.inference_output_type = tf.int8

    tflite_model = converter.convert()
    os.makedirs(os.path.dirname(TFLITE_OUT), exist_ok=True)
    with open(TFLITE_OUT, "wb") as f:
        f.write(tflite_model)

    orig_mb = os.path.getsize(PT_MODEL_PATH) / 1024 / 1024
    quant_mb = os.path.getsize(TFLITE_OUT) / 1024 / 1024
    print(f"TFLite saved: {TFLITE_OUT}")
    print(f"Original: {orig_mb:.1f}MB  Quantized: {quant_mb:.1f}MB ({100*(1-quant_mb/orig_mb):.0f}% reduction)")


if __name__ == "__main__":
    convert_to_tflite()
