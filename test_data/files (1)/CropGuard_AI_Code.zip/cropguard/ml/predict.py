"""
CropGuard Inference Engine
Hybrid confidence scoring: CNN + agronomic rule validation
"""
import numpy as np
import json
import cv2
from typing import Optional

TFLITE_PATH  = "./models/cropguard.tflite"
CLASSES_PATH = "./models/class_names.json"
CONFIDENCE_THRESHOLD = 0.70
IMG_SIZE = 300

CROP_DISEASE_MAP = {
    "tomato": [
        "Tomato_Bacterial_spot", "Tomato_Early_blight", "Tomato_Late_blight",
        "Tomato_Leaf_Mold", "Tomato_Septoria_leaf_spot",
        "Tomato_Spider_mites_Two_spotted_spider_mite",
        "Tomato_Target_Spot", "Tomato_Tomato_Yellow_Leaf_Curl_Virus",
        "Tomato_Tomato_mosaic_virus", "Tomato_healthy",
    ],
    "potato": [
        "Potato_Early_blight", "Potato_Late_blight", "Potato_healthy"
    ],
    "corn": [
        "Corn_(maize)_Cercospora_leaf_spot_Gray_leaf_spot",
        "Corn_(maize)_Common_rust", "Corn_(maize)_Northern_Leaf_Blight",
        "Corn_(maize)_healthy"
    ],
}


def preprocess(image_path: str) -> np.ndarray:
    """CLAHE preprocessing + normalization"""
    img = cv2.imread(image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))

    # CLAHE for contrast enhancement on field images
    lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    lab[:, :, 0] = clahe.apply(lab[:, :, 0])
    img = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)

    img = img.astype(np.float32) / 255.0
    mean = np.array([0.485, 0.456, 0.406])
    std  = np.array([0.229, 0.224, 0.225])
    img  = (img - mean) / std
    return np.expand_dims(img, axis=0).astype(np.float32)


class CropGuardPredictor:
    def __init__(self):
        import tflite_runtime.interpreter as tflite
        self.interpreter = tflite.Interpreter(model_path=TFLITE_PATH)
        self.interpreter.allocate_tensors()
        self.input_idx  = self.interpreter.get_input_details()[0]["index"]
        self.output_idx = self.interpreter.get_output_details()[0]["index"]
        with open(CLASSES_PATH) as f:
            self.classes = json.load(f)
        print(f"Model loaded | {len(self.classes)} classes")

    def predict(self, image_path: str, crop_hint: Optional[str] = None) -> dict:
        """
        Hybrid inference:
        1. Run TFLite model
        2. Check confidence threshold — request 2nd image if < 70%
        3. Apply agronomic rule filter if crop_hint provided
        """
        inp = preprocess(image_path)
        self.interpreter.set_tensor(self.input_idx, inp)
        self.interpreter.invoke()
        logits = self.interpreter.get_tensor(self.output_idx)[0]
        probs  = self._softmax(logits.astype(np.float32))

        top3_idx   = probs.argsort()[-3:][::-1]
        top1_conf  = float(probs[top3_idx[0]])
        top1_cls   = self.classes[top3_idx[0]]

        if top1_conf < CONFIDENCE_THRESHOLD:
            return {
                "status":     "low_confidence",
                "confidence": top1_conf,
                "message":    "Please take another photo from a different angle.",
                "top3":       self._format_top3(probs, top3_idx)
            }

        # Agronomic rule validation
        if crop_hint and crop_hint.lower() in CROP_DISEASE_MAP:
            valid     = CROP_DISEASE_MAP[crop_hint.lower()]
            if top1_cls not in valid:
                valid_idx   = [i for i, c in enumerate(self.classes) if c in valid]
                valid_probs = probs[valid_idx]
                best_valid  = valid_idx[valid_probs.argmax()]
                top1_conf   = float(probs[best_valid])
                top1_cls    = self.classes[best_valid]

        disease, is_healthy = self._parse_class(top1_cls)
        return {
            "status":       "success",
            "disease":      disease,
            "confidence":   top1_conf,
            "is_healthy":   is_healthy,
            "class_raw":    top1_cls,
            "top3":         self._format_top3(probs, top3_idx),
            "needs_action": not is_healthy and top1_conf >= CONFIDENCE_THRESHOLD
        }

    def _softmax(self, x: np.ndarray) -> np.ndarray:
        x = x - x.max()
        e = np.exp(x)
        return e / e.sum()

    def _parse_class(self, cls: str):
        parts      = cls.split("_")
        is_healthy = "healthy" in cls.lower()
        disease    = " ".join(parts[1:]).replace("_", " ").title() if len(parts) > 1 else cls
        return disease, is_healthy

    def _format_top3(self, probs, indices):
        return [{"class": self.classes[i], "confidence": float(probs[i])} for i in indices]


if __name__ == "__main__":
    import sys
    predictor = CropGuardPredictor()
    result    = predictor.predict(sys.argv[1], crop_hint=sys.argv[2] if len(sys.argv) > 2 else None)
    print(json.dumps(result, indent=2))
